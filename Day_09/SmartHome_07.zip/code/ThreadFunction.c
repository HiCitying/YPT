#include "ThreadFunction.h"

void *thread1()
{

//    printf ("thread1 : I'm thread 1\n");
//    for (i = 0; i < MAX; i++)
//    {
//        printf("thread1 : number = %d\n",number);
//        //pthread_mutex_lock(&mut);
//        number++;
//        //pthread_mutex_unlock(&mut);
//        sleep(2);
//    }
//    printf("thread1 :主函数在等我完成任务吗？\n");
//    pthread_exit(NULL);


    while (1)
    {


//        ClearScreen(0,0,100,100,0x00ffffff);
//        sleep(1);
//        ClearScreen(0,0,100,100,0x00ff0000);
//        sleep(1);

        ClearScreen(0,0,800,5,0x00ff0000);
        ClearScreen(475,0,800,5,0x00ff0000);
        ClearScreen(0,0,5,480,0x00ff0000);
        ClearScreen(0,795,5,480,0x00ff0000);
        sleep(1);
        ClearScreen(0,195,5,480,0x00ff0000);
        sleep(1);
        ClearScreen(115,0,195,5,0x00ff0000);
        sleep(1);
        ClearScreen(235,0,195,5,0x00ff0000);
        sleep(1);
        ClearScreen(355,0,195,5,0x00ff0000);
        sleep(1);

        ClearScreen(0,0,800,5,0x00FF7F00);
        ClearScreen(475,0,800,5,0x00FF7F00);
        ClearScreen(0,0,5,480,0x00FF7F00);
        ClearScreen(0,795,5,480,0x00FF7F00);
        sleep(1);
        ClearScreen(0,195,5,480,0x00FF7F00);
        sleep(1);
        ClearScreen(115,0,195,5,0x00FF7F00);
        sleep(1);
        ClearScreen(235,0,195,5,0x00FF7F00);
        sleep(1);
        ClearScreen(355,0,195,5,0x00FF7F00);
        sleep(1);



        ClearScreen(0,0,800,5,0x00FFFF00);
        ClearScreen(475,0,800,5,0x00FFFF00);
        ClearScreen(0,0,5,480,0x00FFFF00);
        ClearScreen(0,795,5,480,0x00FFFF00);
        sleep(1);
        ClearScreen(0,195,5,480,0x00FFFF00);
        sleep(1);
        ClearScreen(115,0,195,5,0x00FFFF00);
        sleep(1);
        ClearScreen(235,0,195,5,0x00FFFF00);
        sleep(1);
        ClearScreen(355,0,195,5,0x00FFFF00);
        sleep(1);


        ClearScreen(0,0,800,5,0x0000FF00);
        ClearScreen(475,0,800,5,0x0000FF00);
        ClearScreen(0,0,5,480,0x0000FF00);
        ClearScreen(0,795,5,480,0x0000FF00);
        sleep(1);
        ClearScreen(0,195,5,480,0x0000FF00);
        sleep(1);
        ClearScreen(115,0,195,5,0x0000FF00);
        sleep(1);
        ClearScreen(235,0,195,5,0x0000FF00);
        sleep(1);
        ClearScreen(355,0,195,5,0x0000FF00);
        sleep(1);


        ClearScreen(0,0,800,5,0x0000FFFF);
        ClearScreen(475,0,800,5,0x0000FFFF);
        ClearScreen(0,0,5,480,0x0000FFFF);
        ClearScreen(0,795,5,480,0x0000FFFF);
        sleep(1);
        ClearScreen(0,195,5,480,0x0000FFFF);
        sleep(1);
        ClearScreen(115,0,195,5,0x0000FFFF);
        sleep(1);
        ClearScreen(235,0,195,5,0x0000FFFF);
        sleep(1);
        ClearScreen(355,0,195,5,0x0000FFFF);
        sleep(1);



        ClearScreen(0,0,800,5,0x000000FF);
        ClearScreen(475,0,800,5,0x000000FF);
        ClearScreen(0,0,5,480,0x000000FF);
        ClearScreen(0,795,5,480,0x000000FF);
        sleep(1);
        ClearScreen(0,195,5,480,0x000000FF);
        sleep(1);
        ClearScreen(115,0,195,5,0x000000FF);
        sleep(1);
        ClearScreen(235,0,195,5,0x000000FF);
        sleep(1);
        ClearScreen(355,0,195,5,0x000000FF);
        sleep(1);



        ClearScreen(0,0,800,5,0x008B00FF);
        ClearScreen(475,0,800,5,0x008B00FF);
        ClearScreen(0,0,5,480,0x008B00FF);
        ClearScreen(0,795,5,480,0x008B00FF);
        sleep(1);
        ClearScreen(0,195,5,480,0x008B00FF);
        sleep(1);
        ClearScreen(115,0,195,5,0x008B00FF);
        sleep(1);
        ClearScreen(235,0,195,5,0x008B00FF);
        sleep(1);
        ClearScreen(355,0,195,5,0x008B00FF);
        sleep(1);



    }
}