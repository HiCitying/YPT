#ifndef _THREADFUNCTION_H_
#define _THREADFUNCTION_H_


#include <pthread.h>

void *thread1();

#endif