#ifndef _PLAY_MUSIC_H_
#define _PLAY_MUSIC_H_



#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
void Play_Music(char *music);

#endif